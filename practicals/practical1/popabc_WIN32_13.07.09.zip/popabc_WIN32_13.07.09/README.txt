13 July 2009

This distribution includes material for the popABC computer program

The directory structure of this archive is as follows
+-base directory
	+--bin
	+--doc
	+--examples
	+--scripts
	+--src

The base directory contains the following files:

README.txt  - this file
LICENSE.txt - GNU license v3 for the popABC software
Makefile - makefile to compile the popabc menu interface and the individual command line executables

The contents of the subdirectories are as follows:

bin - this directory contains the executables compiled for Win32 and related files 

doc - this directory contains popabc related documents

examples - this directory contains example files to use within popabc package and to go through the quick-start guides

scripts - this directory contains several R scripts related to the ABC algorithm (including files from Mark Beaumont's R script package)

src - this directory contains the source code of the popABC package 

Copyright (C) 2009 Joao Lopes and Mark Beaumont
