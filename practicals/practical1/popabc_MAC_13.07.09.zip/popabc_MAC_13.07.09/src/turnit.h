/*
	@author:	joao lopes
	@workplace: Reading University
	@date: 1st May 2009

*/
#ifndef TURNIT_H_
#define TURNIT_H_

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "mylib.h"

#endif /*TURNIT_H_*/
